function updateClock() {
  const now = new Date();

  const time = now.toLocaleTimeString("de-DE");
  const date = now.toLocaleDateString("de-DE", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  });

  document.querySelector("#clock").textContent = time;
  document.querySelector("#date").textContent = date;
}

updateClock();
setInterval(updateClock, 1000);
